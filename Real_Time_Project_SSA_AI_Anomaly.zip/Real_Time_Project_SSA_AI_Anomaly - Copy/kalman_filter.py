# kalman_filter.py
from filterpy.kalman import KalmanFilter
import numpy as np
import matplotlib.pyplot as plt

def kalman_smooth(data):
    """
    Apply Kalman smoothing to the input data.
    
    Args:
        data (numpy.ndarray): Input data with shape (n_samples, 4) containing [x, y, vx, vy]
        
    Returns:
        numpy.ndarray: Smoothed data with the same shape as input
    """
    # Initialize Kalman Filter
    kf = KalmanFilter(dim_x=4, dim_z=4)
    
    # State transition matrix (assume constant velocity model)
    dt = 1.0
    kf.F = np.array([
        [1, 0, dt, 0],
        [0, 1, 0, dt],
        [0, 0, 1, 0],
        [0, 0, 0, 1]
    ])
    
    # Measurement function
    kf.H = np.eye(4)
    
    # Measurement noise
    kf.R *= 5
    
    # Initial state covariance
    kf.P *= 10
    
    # Process noise
    kf.Q = np.eye(4) * 0.01

    # Initial state (first measurement)
    kf.x = np.array([data[0, 0], data[0, 1], 0, 0])

    smoothed = []
    for d in data:
        kf.predict()
        kf.update(d)
        smoothed.append(kf.x.copy())
    
    return np.array(smoothed)

def plot_results(original, smoothed):
    """Plot original vs smoothed data."""
    plt.figure(figsize=(12, 8))
    
    # Plot position (x, y)
    plt.subplot(2, 1, 1)
    plt.plot(original[:, 0], original[:, 1], 'b-', label='Original', alpha=0.5)
    plt.plot(smoothed[:, 0], smoothed[:, 1], 'r-', label='Smoothed')
    plt.title('Orbit Position')
    plt.xlabel('X Position')
    plt.ylabel('Y Position')
    plt.legend()
    plt.axis('equal')
    
    # Plot velocity (vx, vy) magnitude
    plt.subplot(2, 1, 2)
    original_vel = np.sqrt(original[:, 2]**2 + original[:, 3]**2)
    smoothed_vel = np.sqrt(smoothed[:, 2]**2 + smoothed[:, 3]**2)
    plt.plot(original_vel, 'b-', label='Original', alpha=0.5)
    plt.plot(smoothed_vel, 'r-', label='Smoothed')
    plt.title('Velocity Magnitude')
    plt.xlabel('Time Step')
    plt.ylabel('Velocity')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig('kalman_filter_results.png')
    plt.close()

if __name__ == "__main__":
    # Load the generated data
    try:
        data = np.load('orbit_data.npy')
        print(f"Loaded data with shape: {data.shape}")
        
        # Apply Kalman smoothing
        print("Applying Kalman smoothing...")
        smoothed_data = kalman_smooth(data)
        
        # Save smoothed data
        np.save('smoothed_data.npy', smoothed_data)
        print(f"Smoothed data saved to: smoothed_data.npy")
        
        # Plot results
        print("Generating plots...")
        plot_results(data, smoothed_data)
        print("Plots saved to: kalman_filter_results.png")
        
    except FileNotFoundError:
        print("Error: Could not find 'orbit_data.npy'. Please run data_generator.py first.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
