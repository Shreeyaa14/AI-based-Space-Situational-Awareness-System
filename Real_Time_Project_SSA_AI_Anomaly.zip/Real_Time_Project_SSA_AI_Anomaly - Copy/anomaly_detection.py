# anomaly_detection.py
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Dense

def autoencoder_model():
    """Create and return a simple autoencoder model."""
    from tensorflow.keras.layers import Input, Dense
    inp = Input(shape=(4,))
    enc = Dense(8, activation='relu')(inp)
    dec = Dense(4)(enc)
    model = Model(inp, dec)
    model.compile(optimizer='adam', loss='mse')
    return model

def train_autoencoder(normal_data, save_path='autoencoder.h5'):
    """
    Train the autoencoder on normal data only.
    """
    model = autoencoder_model()
    print("Training autoencoder on 1950 Normal samples...")
    model.fit(
        normal_data, normal_data,
        epochs=50,
        batch_size=32,
        validation_split=0.1,
        verbose=1
    )
    model.save(save_path)
    return model

def detect_anomaly_single(model, input_data, threshold):
    """
    Detect if a single input sequence (or batch) matches the normal pattern.
    """
    reconstructed = model.predict(input_data, verbose=0)
    reconstruction_error = np.mean(np.square(input_data - reconstructed), axis=1)
    is_anomaly = reconstruction_error > threshold
    return is_anomaly, reconstruction_error

def detect_anomalies(data, train_ratio=0.75, threshold_percentile=98):
    """
    Detect anomalies using an autoencoder.
    
    Args:
        data (numpy.ndarray): Input data with shape (n_samples, n_features)
        train_ratio (float): Ratio of dta to use for training (0-1)
        threshold_percentile (float): Percentile to use as anomaly threshold
        
    Returns:
        tuple: (is_anomaly, reconstruction_error, model)
    """
    # Split data into train and test sets
    n_train = int(len(data) * train_ratio)
    train_data = data[:n_train]
    
    # Create and train model
    model = autoencoder_model()
    print("Training autoencoder...")
    history = model.fit(
        train_data, train_data,
        epochs=50,
        batch_size=32,
        validation_split=0.2,
        verbose=1
    )
    
    # Calculate reconstruction error
    print("\nDetecting anomalies...")
    reconstructed = model.predict(data)
    reconstruction_error = np.mean(np.square(data - reconstructed), axis=1)
    
    # Determine threshold
    threshold = np.percentile(reconstruction_error, threshold_percentile)
    is_anomaly = reconstruction_error > threshold
    
    print(f"Anomaly detection complete. Threshold: {threshold:.2f}")
    print(f"Detected {np.sum(is_anomaly)} anomalies ({np.mean(is_anomaly)*100:.1f}% of data)")
    
    return is_anomaly, reconstruction_error, model, history

def plot_anomalies(data, is_anomaly, reconstruction_error, save_path='anomaly_detection_results.png'):
    """Plot the original data with anomalies highlighted."""
    plt.figure(figsize=(15, 10))
    
    # Plot position (x, y)
    plt.subplot(2, 1, 1)
    plt.scatter(data[:, 0], data[:, 1], c='blue', alpha=0.5, s=10, label='Normal')
    plt.scatter(data[is_anomaly, 0], data[is_anomaly, 1], 
                c='red', s=30, label='Anomaly')
    plt.title('Detected Anomalies in Position Space')
    plt.xlabel('X Position')
    plt.ylabel('Y Position')
    plt.legend()
    plt.axis('equal')
    
    # Plot reconstruction error over time
    plt.subplot(2, 1, 2)
    plt.plot(reconstruction_error, 'b-', alpha=0.7, label='Reconstruction Error')
    plt.axhline(y=np.percentile(reconstruction_error, 98), 
                color='r', linestyle='--', 
                label=f'98th Percentile ({np.percentile(reconstruction_error, 98):.2f})')
    plt.scatter(np.where(is_anomaly)[0], reconstruction_error[is_anomaly], 
               color='red', zorder=5, label='Detected Anomalies')
    plt.title('Reconstruction Error Over Time')
    plt.xlabel('Time Step')
    plt.ylabel('Mean Squared Error')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
    print(f"\nResults saved to: {save_path}")

if __name__ == "__main__":
    try:
        # Load the smoothed data
        print("Loading data...")
        data = np.load('smoothed_data.npy')
        print(f"Loaded data with shape: {data.shape}")
        
        # Detect anomalies
        is_anomaly, reconstruction_error, model, history = detect_anomalies(data)
        
        # Save results
        np.save('anomaly_predictions.npy', is_anomaly)
        
        # Plot results
        plot_anomalies(data, is_anomaly, reconstruction_error)
        
        # Plot training history
        plt.figure(figsize=(10, 4))
        plt.plot(history.history['loss'], label='Training Loss')
        plt.plot(history.history['val_loss'], label='Validation Loss')
        plt.title('Model Training History')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        plt.savefig('training_history.png')
        plt.close()
        
        print("\nAnomaly detection complete!")
        
    except FileNotFoundError:
        print("Error: Could not find 'smoothed_data.npy'. Please run kalman_filter.py first.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
