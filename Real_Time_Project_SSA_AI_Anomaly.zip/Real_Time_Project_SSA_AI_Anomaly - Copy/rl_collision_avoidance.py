import numpy as np
import matplotlib.pyplot as plt
from collections import deque
import random
import os

class CollisionAvoidanceAgent:
    def __init__(self, state_size=4, action_size=5, learning_rate=0.001, gamma=0.99, epsilon=1.0, epsilon_min=0.01, epsilon_decay=0.995):
        self.state_size = state_size
        self.action_size = action_size
        self.memory = deque(maxlen=2000)
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.epsilon = epsilon
        self.epsilon_min = epsilon_min
        self.epsilon_decay = epsilon_decay
        self.model = self._build_model()
        
    def _build_model(self):
        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import Dense
        from tensorflow.keras.optimizers import Adam
        
        model = Sequential()
        model.add(Dense(24, input_dim=self.state_size, activation='relu'))
        model.add(Dense(24, activation='relu'))
        model.add(Dense(self.action_size, activation='linear'))
        model.compile(loss='mse', optimizer=Adam(learning_rate=self.learning_rate))
        return model
    
    def remember(self, state, action, reward, next_state, done):
        self.memory.append((state, action, reward, next_state, done))
    
    def act(self, state):
        if np.random.rand() <= self.epsilon:
            return random.randrange(self.action_size)
        act_values = self.model.predict(np.array([state]), verbose=0)
        return np.argmax(act_values[0])
    
    def replay(self, batch_size):
        if len(self.memory) < batch_size:
            return
        
        minibatch = random.sample(self.memory, batch_size)
        states = np.array([t[0] for t in minibatch])
        actions = np.array([t[1] for t in minibatch])
        rewards = np.array([t[2] for t in minibatch])
        next_states = np.array([t[3] for t in minibatch])
        dones = np.array([t[4] for t in minibatch])
        
        targets = self.model.predict(states, verbose=0)
        next_q_values = self.model.predict(next_states, verbose=0)
        
        for i in range(len(minibatch)):
            if dones[i]:
                targets[i][actions[i]] = rewards[i]
            else:
                targets[i][actions[i]] = rewards[i] + self.gamma * np.amax(next_q_values[i])
        
        self.model.fit(states, targets, epochs=1, verbose=0)
        
        if self.epsilon > self.epsilon_min:
            self.epsilon *= self.epsilon_decay

def simulate_environment(episodes=1000, batch_size=32):
    # Define action space: [NO_OP, UP, RIGHT, DOWN, LEFT]
    action_effects = np.array([
        [0, 0],      # NO_OP
        [0, 10],     # UP
        [10, 0],     # RIGHT
        [0, -10],    # DOWN
        [-10, 0]     # LEFT
    ])
    
    # Initialize agent
    agent = CollisionAvoidanceAgent(state_size=4, action_size=5)
    
    # For plotting metrics
    scores = []
    
    for e in range(episodes):
        # Reset state: [satellite_x, satellite_y, debris_x, debris_y]
        state = np.array([
            np.random.uniform(-1000, 1000),  # satellite x
            np.random.uniform(-1000, 1000),  # satellite y
            np.random.uniform(-1000, 1000),  # debris x
            np.random.uniform(-1000, 1000)   # debris y
        ])
        
        done = False
        total_reward = 0
        steps = 0
        max_steps = 100
        
        while not done and steps < max_steps:
            # Get action from agent
            action = agent.act(state)
            
            # Take action
            next_state = state.copy()
            next_state[:2] += action_effects[action]  # Move satellite
            
            # Move debris (simplified linear motion)
            debris_direction = -next_state[2:4] / np.linalg.norm(next_state[2:4] + 1e-8)
            next_state[2:4] += debris_direction * 20
            
            # Calculate reward
            distance = np.linalg.norm(next_state[:2] - next_state[2:])
            if distance < 50:  # Collision
                reward = -100
                done = True
            else:
                reward = -0.1  # Small negative reward for each step to encourage efficiency
            
            # Add to memory
            agent.remember(state, action, reward, next_state, done)
            
            total_reward += reward
            state = next_state
            steps += 1
            
            if done:
                break
        
        # Train the agent with experience replay
        if len(agent.memory) > batch_size:
            agent.replay(batch_size)
        
        scores.append(total_reward)
        
        if e % 100 == 0:
            print(f"Episode: {e}/{episodes}, Score: {total_reward}, Epsilon: {agent.epsilon:.2f}")
    
    # Save the trained model
    agent.model.save('collision_avoidance_model.h5')
    print("Model saved to 'collision_avoidance_model.h5'")
    
    # Plot training progress
    plt.figure(figsize=(10, 5))
    plt.plot(scores)
    plt.title('Training Progress')
    plt.xlabel('Episode')
    plt.ylabel('Score')
    plt.savefig('rl_training_progress.png')
    print("Training progress plot saved to 'rl_training_progress.png'")
    plt.close()

def test_agent(episodes=5):
    from tensorflow.keras.models import load_model
    import time
    
    try:
        model = load_model('collision_avoidance_model.h5')
        print("Loaded trained model")
    except:
        print("No trained model found. Please train the agent first.")
        return
    
    action_effects = np.array([
        [0, 0],      # NO_OP
        [0, 10],     # UP
        [10, 0],     # RIGHT
        [0, -10],    # DOWN
        [-10, 0]     # LEFT
    ])
    
    for e in range(episodes):
        state = np.array([
            np.random.uniform(-500, 500),
            np.random.uniform(-500, 500),
            np.random.uniform(-500, 500),
            np.random.uniform(-500, 500)
        ])
        
        done = False
        steps = 0
        max_steps = 50
        
        # Store positions for visualization
        sat_positions = [state[:2].copy()]
        debris_positions = [state[2:].copy()]
        
        while not done and steps < max_steps:
            # Get action (exploration disabled during testing)
            action = np.argmax(model.predict(np.array([state]), verbose=0)[0])
            
            # Take action
            next_state = state.copy()
            next_state[:2] += action_effects[action]
            
            # Move debris
            debris_direction = -next_state[2:4] / np.linalg.norm(next_state[2:4] + 1e-8)
            next_state[2:4] += debris_direction * 20
            
            # Check for collision
            distance = np.linalg.norm(next_state[:2] - next_state[2:])
            if distance < 50:
                print(f"Test {e+1}: Collision detected after {steps} steps!")
                done = True
            
            # Store positions
            sat_positions.append(next_state[:2].copy())
            debris_positions.append(next_state[2:].copy())
            
            state = next_state
            steps += 1
        
        # Plot the episode
        plt.figure(figsize=(8, 8))
        sat_positions = np.array(sat_positions)
        debris_positions = np.array(debris_positions)
        
        plt.plot(sat_positions[:, 0], sat_positions[:, 1], 'b-', label='Satellite')
        plt.plot(debris_positions[:, 0], debris_positions[:, 1], 'r-', label='Debris')
        plt.scatter(sat_positions[0, 0], sat_positions[0, 1], c='g', marker='o', label='Start')
        plt.scatter(sat_positions[-1, 0], sat_positions[-1, 1], c='k', marker='x', label='End')
        
        # Add circles to show safe distance
        for i in range(0, len(sat_positions), 5):
            circle = plt.Circle((sat_positions[i, 0], sat_positions[i, 1]), 50, color='b', alpha=0.1)
            plt.gca().add_patch(circle)
        
        plt.title(f'Test Episode {e+1}')
        plt.xlabel('X Position')
        plt.ylabel('Y Position')
        plt.legend()
        plt.axis('equal')
        plt.grid(True)
        plt.savefig(f'test_episode_{e+1}.png')
        plt.close()
        print(f"Test episode {e+1} visualization saved to 'test_episode_{e+1}.png'")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='RL Collision Avoidance System')
    parser.add_argument('--mode', type=str, default='train', choices=['train', 'test'], 
                       help='Mode: train or test the agent')
    parser.add_argument('--episodes', type=int, default=1000, 
                       help='Number of training episodes')
    
    args = parser.parse_args()
    
    if args.mode == 'train':
        print(f"Starting training for {args.episodes} episodes...")
        simulate_environment(episodes=args.episodes)
    else:
        print("Testing the trained agent...")
        test_agent()
