# data_generator.py
import numpy as np
import os

def generate_orbit_data(n=2000):
    """
    Generate orbital data with injected anomalies.
    
    Args:
        n (int): Number of data points to generate
        
    Returns:
        numpy.ndarray: Array of shape (n, 4) containing [x, y, vx, vy] data
    """
    print(f"Generating {n} data points...")
    t = np.linspace(0, 100, n)
    x = 7000*np.cos(0.01*t)
    y = 7000*np.sin(0.01*t)
    vx = -70*np.sin(0.01*t)
    vy = 70*np.cos(0.01*t)

    data = np.vstack([x, y, vx, vy]).T

    # Inject anomalies
    print("Injecting anomalies...")
    for i in range(1600, 1700):
        data[i] += np.random.normal(0, 300, 4)

    return data

def save_data(data, filename='orbit_data.npy'):
    """Save the generated data to a file."""
    try:
        np.save(filename, data)
        print(f"Data successfully saved to {os.path.abspath(filename)}")
        return True
    except Exception as e:
        print(f"Error saving data: {e}")
        return False

def generate_dataset_for_matching():
    """
    Generates the specific dataset structure requested:
    - 1950 Normal samples
    - 50 Anomalous samples
    """
    print("Generating reference dataset (1950 Normal, 50 Anomalous)...")
    
    # 1. Generate Normal Data (1950 samples)
    t_norm = np.linspace(0, 100, 1950)
    x_norm = 7000 * np.cos(0.01 * t_norm)
    y_norm = 7000 * np.sin(0.01 * t_norm)
    vx_norm = -70 * np.sin(0.01 * t_norm)
    vy_norm = 70 * np.cos(0.01 * t_norm)
    normal_data = np.vstack([x_norm, y_norm, vx_norm, vy_norm]).T
    
    # 2. Generate Anomalous Data (50 samples)
    # Anomalies deviate significantly in position/velocity
    t_anom = np.linspace(100, 105, 50)
    x_anom = 7000 * np.cos(0.01 * t_anom) + np.random.normal(0, 500, 50) # Position jitter
    y_anom = 7000 * np.sin(0.01 * t_anom) + np.random.normal(0, 500, 50)
    vx_anom = -70 * np.sin(0.01 * t_anom) + np.random.normal(0, 50, 50)  # Velocity jitter
    vy_anom = 70 * np.cos(0.01 * t_anom) + np.random.normal(0, 50, 50)
    anomalous_data = np.vstack([x_anom, y_anom, vx_anom, vy_anom]).T
    
    return normal_data, anomalous_data

if __name__ == "__main__":
    # Generate original orbital data
    orbit_data = generate_orbit_data()
    save_data(orbit_data)
    
    # Generate user-requested specific dataset
    norm, anom = generate_dataset_for_matching()
    np.save('dataset_normal.npy', norm)
    np.save('dataset_anomaly.npy', anom)
    print("Saved 'dataset_normal.npy' (1950 samples) and 'dataset_anomaly.npy' (50 samples)")
    
    print("\nData generation complete!")
    print(f"Generated data shape: {orbit_data.shape}")
    print(f"First 5 data points:\n{orbit_data[:5]}")
