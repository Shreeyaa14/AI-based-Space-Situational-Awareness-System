# trajectory_prediction.py
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import LSTM, Dense, Dropout
import os

def create_sequences(data, seq_length=10):
    """Create input sequences and corresponding targets for LSTM training."""
    X, y = [], []
    for i in range(len(data)-seq_length-1):
        X.append(data[i:i+seq_length])
        y.append(data[i+seq_length][:2])  # Predict next position (x,y)
    return np.array(X), np.array(y)

def build_lstm_model(input_shape):
    """Build and compile the LSTM model."""
    model = Sequential([
        LSTM(64, return_sequences=True, input_shape=input_shape),
        Dropout(0.2),
        LSTM(32, return_sequences=False),
        Dropout(0.2),
        Dense(16, activation='relu'),
        Dense(2)  # Predicts x, y coordinates
    ])
    model.compile(optimizer='adam', loss='mse', metrics=['mae'])
    return model

def train_lstm(X_train, y_train, epochs=50, batch_size=32, validation_split=0.2):
    """Train the LSTM model and return the training history."""
    model = build_lstm_model(input_shape=(X_train.shape[1], X_train.shape[2]))
    
    print("Training LSTM model...")
    history = model.fit(
        X_train, y_train,
        epochs=epochs,
        batch_size=batch_size,
        validation_split=validation_split,
        verbose=1
    )
    return model, history

def plot_training_history(history, save_path='training_history_lstm.png'):
    """Plot training and validation loss and MAE."""
    plt.figure(figsize=(12, 4))
    
    # Plot loss
    plt.subplot(1, 2, 1)
    plt.plot(history.history['loss'], label='Training Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Model Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss (MSE)')
    plt.legend()
    
    # Plot MAE
    plt.subplot(1, 2, 2)
    plt.plot(history.history['mae'], label='Training MAE')
    if 'val_mae' in history.history:
        plt.plot(history.history['val_mae'], label='Validation MAE')
    plt.title('Model MAE')
    plt.xlabel('Epoch')
    plt.ylabel('Mean Absolute Error')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
    print(f"Training history plot saved to: {save_path}")

def plot_predictions(y_true, y_pred, save_path='trajectory_predictions.png'):
    """Plot actual vs predicted trajectories."""
    plt.figure(figsize=(12, 6))
    
    # Plot x-coordinate over time
    plt.subplot(2, 1, 1)
    plt.plot(y_true[:, 0], 'b-', label='Actual X')
    plt.plot(y_pred[:, 0], 'r--', label='Predicted X')
    plt.title('X Coordinate Prediction')
    plt.xlabel('Time Step')
    plt.ylabel('X Position')
    plt.legend()
    
    # Plot y-coordinate over time
    plt.subplot(2, 1, 2)
    plt.plot(y_true[:, 1], 'b-', label='Actual Y')
    plt.plot(y_pred[:, 1], 'r--', label='Predicted Y')
    plt.title('Y Coordinate Prediction')
    plt.xlabel('Time Step')
    plt.ylabel('Y Position')
    plt.legend()
    
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()
    print(f"Trajectory predictions plot saved to: {save_path}")

if __name__ == "__main__":
    try:
        # Load the smoothed data
        print("Loading data...")
        data = np.load('smoothed_data.npy')
        print(f"Loaded data with shape: {data.shape}")
        
        # Prepare data for LSTM
        X, y = create_sequences(data)
        print(f"Created sequences - X shape: {X.shape}, y shape: {y.shape}")
        
        # Split into train and test sets
        split = int(0.8 * len(X))
        X_train, X_test = X[:split], X[split:]
        y_train, y_test = y[:split], y[split:]
        
        # Train the model
        model, history = train_lstm(X_train, y_train, epochs=50)
        
        # Save the model
        model.save('trajectory_predictor.h5')
        print("Model saved to: trajectory_predictor.h5")
        
        # Plot training history
        plot_training_history(history)
        
        # Make predictions
        print("\nMaking predictions...")
        y_pred = model.predict(X_test)
        
        # Plot predictions vs actual
        plot_predictions(y_test, y_pred)
        
        # Calculate and print evaluation metrics
        mse = np.mean((y_test - y_pred) ** 2)
        mae = np.mean(np.abs(y_test - y_pred))
        print(f"\nEvaluation Metrics:")
        print(f"Mean Squared Error (MSE): {mse:.2f}")
        print(f"Mean Absolute Error (MAE): {mae:.2f}")
        
    except Exception as e:
        print(f"An error occurred: {str(e)}")
        if 'No such file or directory' in str(e):
            print("Please make sure 'smoothed_data.npy' exists. Run kalman_filter.py first if you haven't already.")
